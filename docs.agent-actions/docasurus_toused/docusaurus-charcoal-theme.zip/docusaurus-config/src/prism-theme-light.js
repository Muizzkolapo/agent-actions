/**
 * Light Mode Prism Theme - Charcoal on Light
 * Place this file at: src/prism-theme-light.js
 */

module.exports = {
  plain: {
    color: '#2d2d2d',
    backgroundColor: '#f5f5f5',
  },
  styles: [
    {
      types: ['comment', 'prolog', 'doctype', 'cdata'],
      style: {
        color: '#999999',
        fontStyle: 'italic',
      },
    },
    {
      types: ['namespace'],
      style: {
        opacity: 0.7,
      },
    },
    {
      types: ['string', 'attr-value'],
      style: {
        color: '#666666',
      },
    },
    {
      types: ['punctuation', 'operator'],
      style: {
        color: '#888888',
      },
    },
    {
      types: ['entity', 'url', 'symbol', 'number', 'boolean', 'variable', 'constant', 'property', 'regex', 'inserted'],
      style: {
        color: '#555555',
      },
    },
    {
      types: ['atrule', 'keyword', 'attr-name', 'selector'],
      style: {
        color: '#888888',
      },
    },
    {
      types: ['function', 'deleted', 'tag'],
      style: {
        color: '#2d2d2d',
      },
    },
    {
      types: ['function-variable'],
      style: {
        color: '#444444',
      },
    },
    {
      types: ['tag', 'selector', 'keyword'],
      style: {
        color: '#666666',
      },
    },
    {
      types: ['important', 'bold'],
      style: {
        fontWeight: 'bold',
      },
    },
    {
      types: ['italic'],
      style: {
        fontStyle: 'italic',
      },
    },
    {
      types: ['class-name'],
      style: {
        color: '#444444',
      },
    },
    {
      types: ['builtin'],
      style: {
        color: '#555555',
      },
    },
  ],
};
