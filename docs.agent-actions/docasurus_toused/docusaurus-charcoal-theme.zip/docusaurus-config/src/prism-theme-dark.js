/**
 * Dark Mode Prism Theme - Light on Dark
 * Place this file at: src/prism-theme-dark.js
 */

module.exports = {
  plain: {
    color: '#e8e8e8',
    backgroundColor: '#111111',
  },
  styles: [
    {
      types: ['comment', 'prolog', 'doctype', 'cdata'],
      style: {
        color: '#555555',
        fontStyle: 'italic',
      },
    },
    {
      types: ['namespace'],
      style: {
        opacity: 0.7,
      },
    },
    {
      types: ['string', 'attr-value'],
      style: {
        color: '#888888',
      },
    },
    {
      types: ['punctuation', 'operator'],
      style: {
        color: '#666666',
      },
    },
    {
      types: ['entity', 'url', 'symbol', 'number', 'boolean', 'variable', 'constant', 'property', 'regex', 'inserted'],
      style: {
        color: '#aaaaaa',
      },
    },
    {
      types: ['atrule', 'keyword', 'attr-name', 'selector'],
      style: {
        color: '#666666',
      },
    },
    {
      types: ['function', 'deleted', 'tag'],
      style: {
        color: '#e8e8e8',
      },
    },
    {
      types: ['function-variable'],
      style: {
        color: '#cccccc',
      },
    },
    {
      types: ['tag', 'selector', 'keyword'],
      style: {
        color: '#777777',
      },
    },
    {
      types: ['important', 'bold'],
      style: {
        fontWeight: 'bold',
      },
    },
    {
      types: ['italic'],
      style: {
        fontStyle: 'italic',
      },
    },
    {
      types: ['class-name'],
      style: {
        color: '#cccccc',
      },
    },
    {
      types: ['builtin'],
      style: {
        color: '#999999',
      },
    },
  ],
};
