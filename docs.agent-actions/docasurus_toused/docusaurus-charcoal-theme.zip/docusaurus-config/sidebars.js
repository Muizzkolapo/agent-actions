/**
 * Sidebars Configuration
 * Place this file at: sidebars.js (root level)
 */

/** @type {import('@docusaurus/plugin-content-docs').SidebarsConfig} */
const sidebars = {
  docs: [
    {
      type: 'category',
      label: 'Documentation',
      collapsed: false,
      items: [
        'introduction',
        {
          type: 'category',
          label: 'Getting Started',
          collapsed: false,
          items: [
            'getting-started/quick-start',
            'getting-started/prerequisites',
            'getting-started/first-steps',
          ],
        },
        {
          type: 'category',
          label: 'Installation',
          items: [
            'installation/npm',
            'installation/yarn',
            'installation/pnpm',
          ],
        },
        {
          type: 'category',
          label: 'Configuration',
          items: [
            'configuration/basic-config',
            'configuration/advanced-options',
            'configuration/environment',
          ],
        },
        {
          type: 'category',
          label: 'API Reference',
          items: [
            'api/methods',
            'api/events',
            'api/types',
          ],
        },
        'examples',
      ],
    },
  ],
};

module.exports = sidebars;
