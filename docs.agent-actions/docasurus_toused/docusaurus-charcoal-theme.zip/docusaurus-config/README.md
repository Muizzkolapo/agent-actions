# Charcoal Text Minimalist Docusaurus Theme

A refined, minimalist documentation theme with charcoal text and support for both light and dark modes.

## Quick Setup

### 1. Create a new Docusaurus project (if starting fresh)

```bash
npx create-docusaurus@latest my-docs classic
cd my-docs
```

### 2. Copy the configuration files

Place the files in these locations:

```
your-project/
├── docusaurus.config.js         # Main config (replace existing)
├── sidebars.js                  # Sidebar config (replace existing)
├── src/
│   ├── css/
│   │   └── custom.css           # Main theme styles
│   ├── prism-theme-light.js     # Light mode code syntax
│   └── prism-theme-dark.js      # Dark mode code syntax
└── static/
    └── img/
        └── logo.svg             # Logo file
```

### 3. Update the config

In `docusaurus.config.js`, update:

- `title` - Your tool name
- `url` - Your site URL
- `organizationName` and `projectName` - Your GitHub info

### 4. Run the dev server

```bash
npm start
```

---

## Design System

### Light Mode Colors (Default)

| Token | Hex | Usage |
|-------|-----|-------|
| Background | `#fafafa` | Main background |
| Surface | `#ffffff` | Cards, elevated areas |
| Text Primary | `#2d2d2d` | Headings, body text |
| Text Secondary | `#555555` | Secondary content |
| Text Muted | `#888888` | Labels, hints |
| Border | `#e0e0e0` | Standard borders |
| Code Background | `#f5f5f5` | Code blocks |

### Dark Mode Colors

| Token | Hex | Usage |
|-------|-----|-------|
| Background | `#0d0d0d` | Main background |
| Surface | `#111111` | Cards, code blocks |
| Text Primary | `#e8e8e8` | Headings, body text |
| Text Secondary | `#aaaaaa` | Secondary content |
| Text Muted | `#666666` | Labels, hints |
| Border | `#1f1f1f` | Standard borders |

### Typography

| Element | Font | Weight | Size |
|---------|------|--------|------|
| H1 (Page title) | Source Serif 4 | 300 | 42px |
| H2 (Sections) | Instrument Sans | 600 | 13px (uppercase) |
| H3 (Subsections) | Instrument Sans | 500 | 14px |
| Body | Instrument Sans | 400 | 16px |
| Code | JetBrains Mono | 400 | 13px |

---

## Key Config Settings

### Color Mode Toggle

```js
// docusaurus.config.js
colorMode: {
  defaultMode: 'light',      // Start in light mode
  disableSwitch: false,      // Show toggle button
  respectPrefersColorScheme: true,  // Follow system preference
},
```

### To Default to Dark Mode

```js
colorMode: {
  defaultMode: 'dark',
  disableSwitch: false,
  respectPrefersColorScheme: true,
},
```

### To Lock to One Mode

```js
// Light mode only
colorMode: {
  defaultMode: 'light',
  disableSwitch: true,
  respectPrefersColorScheme: false,
},

// Dark mode only
colorMode: {
  defaultMode: 'dark',
  disableSwitch: true,
  respectPrefersColorScheme: false,
},
```

---

## Customization

### Changing the Accent Color

The theme uses the primary text color as the accent. To add a colored accent:

```css
/* In custom.css - add to both :root and [data-theme='dark'] */
:root {
  --accent-color: #6b7280;  /* slate gray example */
}

.menu__link--active {
  border-left-color: var(--accent-color);
}

.navbar__link--active::after {
  background-color: var(--accent-color);
}
```

### Adjusting Text Contrast

For higher contrast in light mode:

```css
:root {
  --ifm-font-color-base: #1a1a1a;      /* darker */
  --ifm-font-color-secondary: #404040;
}
```

For lower contrast (softer look):

```css
:root {
  --ifm-font-color-base: #404040;      /* lighter */
  --ifm-font-color-secondary: #666666;
}
```

---

## Troubleshooting

### Fonts not loading

Make sure the Google Fonts stylesheet is in your config:

```js
stylesheets: [
  {
    href: 'https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,300;8..60,400;8..60,600&family=JetBrains+Mono:wght@400;500&family=Instrument+Sans:wght@400;500;600&display=swap',
    type: 'text/css',
  },
],
```

### Theme toggle not appearing

Check that `disableSwitch` is set to `false` in your colorMode config.

### CSS not applying

Clear the cache and rebuild:

```bash
npm run clear
npm run build
```

---

## File Summary

| File | Purpose |
|------|---------|
| `docusaurus.config.js` | Main config with color mode toggle enabled |
| `src/css/custom.css` | All styling with light/dark CSS variables |
| `src/prism-theme-light.js` | Charcoal syntax highlighting for light mode |
| `src/prism-theme-dark.js` | Light syntax highlighting for dark mode |
| `sidebars.js` | Sidebar navigation structure |
| `static/img/logo.svg` | Minimal logo |

---

## License

MIT
